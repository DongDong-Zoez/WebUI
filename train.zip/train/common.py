import streamlit as st

def save_config(lang: str) -> None:
    # Store the selected language in Streamlit's session state (persistent across reruns)
    st.session_state.lang = lang
    st.write(f"Language saved: {lang}")
