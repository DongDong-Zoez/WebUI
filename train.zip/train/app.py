import os
from interface import create_ui


if __name__ == "__main__":
    demo = create_ui(demo_mode=int(os.environ.get("DEMO_MODE", "0")))