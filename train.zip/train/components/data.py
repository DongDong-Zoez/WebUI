import json
import os
import streamlit as st
from typing import List, Dict, Any

PAGE_SIZE = 2
DATA_CONFIG = "dataset_info.json"  # Adjust if DATA_CONFIG is defined elsewhere


def load_data_file(file_path: str) -> List[Any]:
    """Load data from a JSON, JSONL, or other file types."""
    with open(file_path, encoding="utf-8") as f:
        if file_path.endswith(".json"):
            return json.load(f)
        elif file_path.endswith(".jsonl"):
            return [json.loads(line) for line in f]
        else:
            return list(f)

def get_preview(dataset_dir: str, dataset: str, page_index: int) -> Dict[str, Any]:
    """Get a preview of the dataset."""
    with open(os.path.join(dataset_dir, DATA_CONFIG), encoding="utf-8") as f:
        dataset_info = json.load(f)

    data = []
    data_path = [os.path.join(dataset_dir, dataset_info[name]["file_name"]) for name in dataset]
    for path in data_path:
        data.extend(load_data_file(path))

    total_data = len(data)
    paginated_data = data[PAGE_SIZE * page_index : PAGE_SIZE * (page_index + 1)]

    return {
        "total_data": total_data,
        "paginated_data": paginated_data,
        "show_preview": True,
    }


def prev_page(current_page: int) -> int:
    """Get the previous page index."""
    return max(0, current_page - 1)


def next_page(current_page: int, total_data: int) -> int:
    """Get the next page index."""
    max_page = (total_data - 1) // PAGE_SIZE
    return min(max_page, current_page + 1)


@st.dialog("DatasetPreview")
def create_preview_box(dataset_dir, dataset):
    # Initialize session state to hold page index and preview count
    if 'page_index' not in st.session_state:
        st.session_state.page_index = 0
    preview = get_preview(dataset_dir, dataset, st.session_state.page_index)
    if 'preview_count' not in st.session_state:
        st.session_state.preview_count = preview["total_data"]
    if 'preview_samples' not in st.session_state:
        st.session_state.preview_samples = preview["paginated_data"]
    if 'preview_box_visible' not in st.session_state:
        st.session_state.preview_box_visible = True

    # Display preview box if visible
    if st.session_state.preview_box_visible:
        with st.container():
            # Display preview count and page index
            st.write(f"Total Samples: {st.session_state.preview_count}")

            # Navigation buttons for pagination
            col1, col2, col3 = st.columns([1, 1, 1])
            with col1:
                if st.button("Previous", key="prev"):
                    st.session_state.page_index = prev_page(st.session_state.page_index)
                    preview = get_preview(dataset_dir, dataset, st.session_state.page_index)
                    st.session_state.preview_samples = preview["paginated_data"]
                    st.session_state.preview_count = preview["total_data"]
                    # st.rerun()

            with col2:
                if st.button("Next", key="next"):
                    st.session_state.page_index = next_page(st.session_state.page_index, st.session_state.preview_count)
                    preview = get_preview(dataset_dir, dataset, st.session_state.page_index)
                    st.session_state.preview_samples = preview["paginated_data"]
                    st.session_state.preview_count = preview["total_data"]
                    # st.rerun()

            with col3:
                if st.button("Close Preview", key="close"):
                    st.session_state.preview_box_visible = False
                    st.rerun()

            st.write(f"Page: {st.session_state.page_index + 1}")

            # Show preview samples (JSON format)
            st.json(st.session_state.preview_samples)