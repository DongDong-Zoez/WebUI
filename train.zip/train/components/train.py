import streamlit as st
from typing import Any, Dict
from .data import create_preview_box, get_preview


def create_train_tab(engine: Any) -> Dict[str, Any]:
    elem_dict = {}

    st.header("Training Configuration")
    
    # Dropdown for training stage
    training_stage = st.selectbox("Training Stage", options=["stage1", "stage2", "stage3"])
    dataset_dir = st.text_input("Dataset Directory", value="/path/to/dataset")

    dataset = st.multiselect("Dataset", options=["dataset1", "dataset2", "dataset3"])
    st.text("Preview: Dataset directory and selected dataset")

    elem_dict.update(
        dict(training_stage=training_stage, dataset_dir=dataset_dir, dataset=dataset)
    )

    if st.button("Show Preview"):
        create_preview_box("./", ["identity"])
        # st.session_state.page_index = 0
        # st.session_state.preview_box_visible = True
        # preview = get_preview("./", ["identity"], st.session_state.page_index)
        # st.session_state.preview_samples = preview["paginated_data"]
        # st.session_state.preview_count = preview["total_data"]
        # st.rerun()
        

# Render preview box
    # Text inputs for various parameters
    learning_rate = st.text_input("Learning Rate", value="5e-5")
    num_train_epochs = st.text_input("Number of Training Epochs", value="3.0")
    max_grad_norm = st.text_input("Max Gradient Norm", value="1.0")
    max_samples = st.text_input("Max Samples", value="100000")
    compute_type = st.selectbox("Compute Type", options=["bf16", "fp16", "fp32", "pure_bf16"])

    elem_dict.update(
        dict(
            learning_rate=learning_rate,
            num_train_epochs=num_train_epochs,
            max_grad_norm=max_grad_norm,
            max_samples=max_samples,
            compute_type=compute_type,
        )
    )

    # Additional UI elements
    cutoff_len = st.slider("Cutoff Length", min_value=4, max_value=131072, value=2048, step=1)
    batch_size = st.slider("Batch Size", min_value=1, max_value=1024, value=2, step=1)
    gradient_accumulation_steps = st.slider(
        "Gradient Accumulation Steps", min_value=1, max_value=1024, value=8, step=1
    )
    val_size = st.slider("Validation Size", min_value=0.0, max_value=1.0, value=0.1, step=0.001)
    lr_scheduler_type = st.selectbox("LR Scheduler Type", options=["linear", "cosine", "constant"])

    elem_dict.update(
        dict(
            cutoff_len=cutoff_len,
            batch_size=batch_size,
            gradient_accumulation_steps=gradient_accumulation_steps,
            val_size=val_size,
            lr_scheduler_type=lr_scheduler_type,
        )
    )

    # Buttons for actions
    if st.button("Preview Command"):
        engine.runner.preview_train(elem_dict, None)

    if st.button("Start Training"):
        engine.runner.run_train(elem_dict, None)

    if st.button("Stop Training"):
        engine.runner.set_abort()

    return elem_dict