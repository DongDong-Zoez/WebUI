import streamlit as st
from .chatbot import create_chat_box


def create_infer_tab(engine):
    """
    Create the inference tab using Streamlit.
    This replicates the behavior of the Gradio version.
    """

    # Initialize session state for tracking inputs and outputs
    if "infer_state" not in st.session_state:
        st.session_state.infer_state = {
            "infer_backend": "huggingface",
            "infer_dtype": "auto",
            "info_box": "",
            "chat_messages": [],
            "model_loaded": False,
        }

    infer_state = st.session_state.infer_state

    # Backend and Data Type Selection
    st.subheader("Inference Settings")
    infer_state["infer_backend"] = st.selectbox(
        "Inference Backend", options=["huggingface", "vllm"], index=0
    )
    infer_state["infer_dtype"] = st.selectbox(
        "Inference Data Type", options=["auto", "float16", "bfloat16", "float32"], index=0
    )

    # Load and Unload Buttons
    st.subheader("Model Management")
    col1, col2 = st.columns(2)
    with col1:
        if st.button("Load Model", disabled=infer_state["model_loaded"]):
            infer_state["info_box"] = engine.chatter.load_model(infer_state)
            infer_state["model_loaded"] = True
    with col2:
        if st.button("Unload Model", disabled=not infer_state["model_loaded"]):
            infer_state["info_box"] = engine.chatter.unload_model(infer_state)
            infer_state["model_loaded"] = False
            infer_state["chat_messages"] = []

    # Display Information Box
    st.text_area("Info Box", value=infer_state["info_box"], height=150)

    # Chatbot UI
    st.subheader("Chat Interface")
    if infer_state["model_loaded"]:
        chat_container = st.container()
        create_chat_box(chat_container, infer_state)  # Add chatbot UI logic
    else:
        st.warning("Load a model to activate the chat interface.")

    # Multimedia Box Visibility
    st.subheader("Multimedia Support")
    model_name = st.text_input("Model Name", "")
    # mm_box_visible = get_visual(model_name)
    mm_box_visible = ["visual_model"]
    if mm_box_visible:
        st.write("Multimedia Box is now visible.")
    else:
        st.write("No multimedia support for the selected model.")

    return infer_state

