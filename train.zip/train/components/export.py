import os
import json
import streamlit as st
from typing import Union, List, Generator, Optional, Dict, Any

PEFT_METHODS = {"lora"}
GPTQ_BITS = ["8", "4", "3", "2"]

from transformers.utils import (
    is_torch_bf16_gpu_available,
    is_torch_cuda_available,
    is_torch_mps_available,
    is_torch_npu_available,
    is_torch_xpu_available,
)

def torch_gc() -> None:
    r"""
    Collects GPU or NPU memory.
    """
    gc.collect()
    if is_torch_xpu_available():
        torch.xpu.empty_cache()
    elif is_torch_npu_available():
        torch.npu.empty_cache()
    elif is_torch_mps_available():
        torch.mps.empty_cache()
    elif is_torch_cuda_available():
        torch.cuda.empty_cache()

def export_model(args: Optional[Dict[str, Any]] = None) -> None:
    model_args, data_args, finetuning_args, _ = get_infer_args(args)

    if model_args.export_dir is None:
        raise ValueError("Please specify `export_dir` to save model.")

    if model_args.adapter_name_or_path is not None and model_args.export_quantization_bit is not None:
        raise ValueError("Please merge adapters before quantizing the model.")

    tokenizer_module = load_tokenizer(model_args)
    tokenizer = tokenizer_module["tokenizer"]
    processor = tokenizer_module["processor"]
    get_template_and_fix_tokenizer(tokenizer, data_args)
    model = load_model(tokenizer, model_args, finetuning_args)  # must after fixing tokenizer to resize vocab

    if getattr(model, "quantization_method", None) is not None and model_args.adapter_name_or_path is not None:
        raise ValueError("Cannot merge adapters to a quantized model.")

    if not isinstance(model, PreTrainedModel):
        raise ValueError("The model is not a `PreTrainedModel`, export aborted.")

    if getattr(model, "quantization_method", None) is not None:  # quantized model adopts float16 type
        setattr(model.config, "torch_dtype", torch.float16)
    else:
        if model_args.infer_dtype == "auto":
            output_dtype = getattr(model.config, "torch_dtype", torch.float16)
        else:
            output_dtype = getattr(torch, model_args.infer_dtype)

        setattr(model.config, "torch_dtype", output_dtype)
        model = model.to(output_dtype)
        logger.info_rank0(f"Convert model dtype to: {output_dtype}.")

    model.save_pretrained(
        save_directory=model_args.export_dir,
        max_shard_size=f"{model_args.export_size}GB",
        safe_serialization=(not model_args.export_legacy_format),
    )
    if model_args.export_hub_model_id is not None:
        model.push_to_hub(
            model_args.export_hub_model_id,
            token=model_args.hf_hub_token,
            max_shard_size=f"{model_args.export_size}GB",
            safe_serialization=(not model_args.export_legacy_format),
        )

    if finetuning_args.stage == "rm":
        if model_args.adapter_name_or_path is not None:
            vhead_path = model_args.adapter_name_or_path[-1]
        else:
            vhead_path = model_args.model_name_or_path

        if os.path.exists(os.path.join(vhead_path, V_HEAD_SAFE_WEIGHTS_NAME)):
            shutil.copy(
                os.path.join(vhead_path, V_HEAD_SAFE_WEIGHTS_NAME),
                os.path.join(model_args.export_dir, V_HEAD_SAFE_WEIGHTS_NAME),
            )
            logger.info_rank0(f"Copied valuehead to {model_args.export_dir}.")
        elif os.path.exists(os.path.join(vhead_path, V_HEAD_WEIGHTS_NAME)):
            shutil.copy(
                os.path.join(vhead_path, V_HEAD_WEIGHTS_NAME),
                os.path.join(model_args.export_dir, V_HEAD_WEIGHTS_NAME),
            )
            logger.info_rank0(f"Copied valuehead to {model_args.export_dir}.")

    try:
        tokenizer.padding_side = "left"  # restore padding side
        tokenizer.init_kwargs["padding_side"] = "left"
        tokenizer.save_pretrained(model_args.export_dir)
        if model_args.export_hub_model_id is not None:
            tokenizer.push_to_hub(model_args.export_hub_model_id, token=model_args.hf_hub_token)

        if processor is not None:
            processor.save_pretrained(model_args.export_dir)
            if model_args.export_hub_model_id is not None:
                processor.push_to_hub(model_args.export_hub_model_id, token=model_args.hf_hub_token)

    except Exception as e:
        logger.warning_rank0(f"Cannot save tokenizer, please copy the files manually: {e}.")

PAGE_SIZE = 2


def can_quantize(checkpoint_path: Union[str, List[str]]) -> bool:
    """Check whether quantization can be done based on the checkpoint path."""
    if isinstance(checkpoint_path, list) and len(checkpoint_path) != 0:
        return False
    return True


def save_model(
    lang: str,
    model_name: str,
    model_path: str,
    finetuning_type: str,
    checkpoint_path: Union[str, List[str]],
    template: str,
    export_size: int,
    export_quantization_bit: str,
    export_quantization_dataset: str,
    export_device: str,
    export_legacy_format: bool,
    export_dir: str,
    export_hub_model_id: str,
) -> Generator[str, None, None]:
    """Function to save and export the model based on the provided parameters."""
    error = ""
    if not model_name:
        error = ALERTS["err_no_model"][lang]
    elif not model_path:
        error = ALERTS["err_no_path"][lang]
    elif not export_dir:
        error = ALERTS["err_no_export_dir"][lang]
    elif export_quantization_bit in GPTQ_BITS and not export_quantization_dataset:
        error = ALERTS["err_no_dataset"][lang]
    elif export_quantization_bit not in GPTQ_BITS and not checkpoint_path:
        error = ALERTS["err_no_adapter"][lang]
    elif export_quantization_bit in GPTQ_BITS and checkpoint_path and isinstance(checkpoint_path, list):
        error = ALERTS["err_gptq_lora"][lang]

    if error:
        st.warning(error)
        yield error
        return

    # Setup arguments
    args = dict(
        model_name_or_path=model_path,
        finetuning_type=finetuning_type,
        template=template,
        export_dir=export_dir,
        export_hub_model_id=export_hub_model_id or None,
        export_size=export_size,
        export_quantization_bit=int(export_quantization_bit) if export_quantization_bit in GPTQ_BITS else None,
        export_quantization_dataset=export_quantization_dataset,
        export_device=export_device,
        export_legacy_format=export_legacy_format,
    )

    if checkpoint_path:
        if finetuning_type in PEFT_METHODS:  # list
            args["adapter_name_or_path"] = ",".join(checkpoint_path)
        else:  # str
            args["model_name_or_path"] = checkpoint_path

    yield ALERTS["info_exporting"][lang]
    export_model(args)
    torch_gc()
    yield ALERTS["info_exported"][lang]


def create_export_tab(engine) -> dict:
    col1, col2 = st.columns(2)

    # First row: settings for export
    with col1:
        export_size = st.slider("Export Size (%)", min_value=1, max_value=100, value=5, step=1)
        export_quantization_bit = st.selectbox("Quantization Bits", options=["none"] + GPTQ_BITS, index=0)
        export_quantization_dataset = st.text_input("Quantization Dataset", value="data/c4_demo.json")
        export_device = st.radio("Device", options=["cpu", "auto"], index=0)
        export_legacy_format = st.checkbox("Use Legacy Format")

    with col2:
        export_dir = st.text_input("Export Directory")
        export_hub_model_id = st.text_input("Hub Model ID")

    # Placeholder for model selection
    # Assuming these values are available in the `engine` context
    checkpoint_path = st.selectbox("Checkpoint Path", ["Model A", "Model B", "Model C"])  # Replace with real checkpoint paths

    # Export button and info box
    export_btn = st.button("Export Model")
    info_box = st.empty()

    if export_btn:
        # Assuming we have necessary values in engine or UI elements
        lang = "en"  # Replace with dynamic language selection
        model_name = "example_model"  # Replace with dynamic model selection
        model_path = "path/to/model"  # Replace with actual path
        finetuning_type = "none"  # Replace with actual finetuning type
        template = "default"  # Replace with actual template
        # Call save_model function to handle export logic
        save_model(
            lang, model_name, model_path, finetuning_type, checkpoint_path, template,
            export_size, export_quantization_bit, export_quantization_dataset,
            export_device, export_legacy_format, export_dir, export_hub_model_id
        )
        info_box.success("Export initiated successfully!")

    # Return the components as a dictionary
    return {
        "export_size": export_size,
        "export_quantization_bit": export_quantization_bit,
        "export_quantization_dataset": export_quantization_dataset,
        "export_device": export_device,
        "export_legacy_format": export_legacy_format,
        "export_dir": export_dir,
        "export_hub_model_id": export_hub_model_id,
        "checkpoint_path": checkpoint_path,
        "export_btn": export_btn,
        "info_box": info_box,
    }