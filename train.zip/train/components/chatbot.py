import streamlit as st
from enum import Enum, unique
import json

def check_json_schema(text: str, lang: str) -> None:
    r"""
    Checks if the json schema is valid and displays warnings using Streamlit.
    """
    try:
        tools = json.loads(text)
        if tools:
            assert isinstance(tools, list)
            for tool in tools:
                if "name" not in tool:
                    raise NotImplementedError("Name not found.")
    except NotImplementedError:
        st.warning(ALERTS["err_tool_name"][lang])
    except Exception:
        st.warning(ALERTS["err_json_schema"][lang])

@unique
class Role(str, Enum):
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"
    FUNCTION = "function"
    OBSERVATION = "observation"


def create_chat_box(engine):
    st.title("Chat Box")

    # Chat history
    st.subheader("Chat History")
    chatbot = st.empty()
    messages = st.session_state.get("messages", [])

    # Role and system inputs
    st.subheader("Inputs")
    col1, col2 = st.columns([4, 1])
    with col1:
        role = st.selectbox("Role", [Role.USER.value, Role.OBSERVATION.value], index=0)
        system = st.text_input("System Input")
        tools = st.text_area("Tools Input", height=80)

        # Multimedia tabs
        tab1, tab2 = st.tabs(["Image", "Video"])
        with tab1:
            image = st.file_uploader("Upload an Image", type=["png", "jpg", "jpeg"])
        with tab2:
            video = st.file_uploader("Upload a Video", type=["mp4", "avi"])

        query = st.text_area("Query", height=150)
        submit_btn = st.button("Submit")

    with col2:
        max_new_tokens = st.slider("Max New Tokens", 8, 4096, 512, step=1)
        top_p = st.slider("Top-p", 0.01, 1.0, 0.7, step=0.01)
        temperature = st.slider("Temperature", 0.01, 1.5, 0.95, step=0.01)
        clear_btn = st.button("Clear")

    # Handle tool input validation
    if st.button("Validate Tools"):
        if not check_json_schema(tools, engine.manager.get_elem_by_id("top.lang")):
            st.error("Invalid tools input!")

    # Handle submission
    if submit_btn:
        new_message = {"role": role, "query": query}
        messages.append(new_message)
        st.session_state["messages"] = messages

        chatbot.write("Chatbot Updated:")
        for message in messages:
            st.write(f"**{message['role']}**: {message['query']}")

        # Simulate engine chatter (replace with actual engine logic)
        engine_output = engine.chatter.stream(
            chatbot=messages,
            system=system,
            tools=tools,
            image=image,
            video=video,
            max_new_tokens=max_new_tokens,
            top_p=top_p,
            temperature=temperature,
        )
        messages.append({"role": "Chatbot", "query": engine_output})

    # Handle clearing
    if clear_btn:
        st.session_state["messages"] = []
        chatbot.write("Chat history cleared!")

    return {
        "chatbot": chatbot,
        "messages": messages,
        "role": role,
        "system": system,
        "tools": tools,
        "image": image,
        "video": video,
        "query": query,
        "max_new_tokens": max_new_tokens,
        "top_p": top_p,
        "temperature": temperature,
    }

