import streamlit as st
from typing import Dict, Any
import os
import json

from .data import create_preview_box

DEFAULT_DATA_DIR = "."

def load_dataset_info(dataset_dir: str) -> Dict[str, Dict[str, Any]]:
    """
    Loads dataset_info.json.
    """
    if dataset_dir == "ONLINE" or dataset_dir.startswith("REMOTE:"):
        st.info(f"dataset_dir is {dataset_dir}, using online dataset.")
        return {}

    try:
        with open(os.path.join(dataset_dir, "dataset_info.json"), encoding="utf-8") as f:
            return json.load(f)
    except Exception as err:
        st.warning(f"Cannot open dataset_info.json due to {str(err)}.")
        return {}

def list_datasets(dataset_dir: str = None, training_stage: str = "stage1") -> None:
    """
    Lists all available datasets in the dataset dir for the training stage.
    """
    dataset_info = load_dataset_info(dataset_dir if dataset_dir is not None else DEFAULT_DATA_DIR)
    datasets = [k for k, v in dataset_info.items()]
    return st.selectbox("Select Dataset", options=datasets)



def create_eval_tab(engine):
    """
    Create the evaluation tab using Streamlit.
    This replicates the behavior of the Gradio version.
    """
    # Initialize session state for tracking inputs and outputs
    if "eval_state" not in st.session_state:
        st.session_state.eval_state = {
            "dataset_dir": DEFAULT_DATA_DIR,
            "dataset": [],
            "cutoff_len": 1024,
            "max_samples": "100000",
            "batch_size": 2,
            "predict": True,
            "max_new_tokens": 512,
            "top_p": 0.7,
            "temperature": 0.95,
            "output_dir": "",
            "output_box": "",
            "progress": 0,
            "is_running": False,
        }

    eval_state = st.session_state.eval_state

    # Dataset Selection
    st.subheader("Dataset Selection")
    eval_state["dataset_dir"] = st.text_input("Dataset Directory", value=eval_state["dataset_dir"])
    if st.button("List Datasets"):
        eval_state["dataset"] = list_datasets(eval_state["dataset_dir"])
    eval_state["dataset"] = st.multiselect("Select Dataset(s)", options=eval_state["dataset"])

    # Preview the dataset (if applicable)
    st.write("Preview")
    create_preview_box(eval_state["dataset_dir"], eval_state["dataset"])  # Placeholder for actual preview logic

    # Evaluation Parameters
    st.subheader("Evaluation Parameters")
    eval_state["cutoff_len"] = st.slider("Cutoff Length", min_value=4, max_value=131072, value=eval_state["cutoff_len"])
    eval_state["max_samples"] = st.text_input("Eval Max Samples", value=eval_state["max_samples"])
    eval_state["batch_size"] = st.slider("Batch Size", min_value=1, max_value=1024, value=eval_state["batch_size"])
    eval_state["predict"] = st.checkbox("Predict Mode", value=eval_state["predict"])

    # Generation Parameters
    st.subheader("Generation Parameters")
    eval_state["max_new_tokens"] = st.slider("Max New Tokens", min_value=8, max_value=4096, value=eval_state["max_new_tokens"])
    eval_state["top_p"] = st.slider("Top-p", min_value=0.01, max_value=1.0, value=eval_state["top_p"], step=0.01)
    eval_state["temperature"] = st.slider("Temperature", min_value=0.01, max_value=1.5, value=eval_state["temperature"], step=0.01)
    eval_state["output_dir"] = st.text_input("Output Directory", value=eval_state["output_dir"])

    # Buttons for Actions
    st.subheader("Actions")
    col1, col2, col3 = st.columns(3)
    with col1:
        if st.button("Eval Preview Command"):
            st.write("Command Preview:")
            st.write(engine.runner.preview_eval(eval_state))  # Placeholder for preview logic
    with col2:
        if st.button("Start Evaluation", disabled=eval_state["is_running"]):
            eval_state["is_running"] = True
            engine.runner.run_eval(eval_state)  # Run evaluation
            eval_state["is_running"] = False
    with col3:
        if st.button("Stop Evaluation", disabled=not eval_state["is_running"]):
            engine.runner.set_abort()
            eval_state["is_running"] = False

    # Progress and Output
    st.subheader("Progress and Output")
    eval_state["progress"] = st.progress(eval_state["progress"])
    eval_state["output_box"] = st.text_area("Output Log", value=eval_state["output_box"], height=300)

    # Monitor Evaluation
    if eval_state["is_running"]:
        engine.runner.monitor(eval_state)

    return eval_state

