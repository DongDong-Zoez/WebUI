import streamlit as st
from typing import Dict, Any

# Simulating the external constants and functions
TEMPLATES = {"default": {}, "template1": {}, "template2": {}}
METHODS = ["lora", "full", "partial"]
SUPPORTED_MODELS = {"Model A": {}, "Model B": {}, "Model C": {}}

def get_model_info(model_name: str) -> Dict[str, Any]:
    # Simulate fetching model info
    return {"path": f"/path/to/{model_name}", "template": "default"}

def list_checkpoints(model_name: str, finetuning_type: str) -> list:
    # Simulate listing checkpoints
    return [f"checkpoint_{i}" for i in range(1, 6)]

def save_config(*args, **kwargs):
    # Simulate saving config
    st.write("Config saved with arguments:", args)

def can_quantize(finetuning_type: str) -> list:
    # Simulate available quantization options
    return ["none", "8", "4"] if finetuning_type == "lora" else ["none"]

def can_quantize_to(method: str) -> list:
    # Simulate method-specific quantization bits
    return ["8", "4"] if method == "bitsandbytes" else ["none"]

def create_top() -> Dict[str, Any]:
    components = {}

    # First container: Row 1 - Language, Model Name, Model Path
    with st.container(border=True):  # First container
        col1, col2, col3 = st.columns([1, 3, 3])
        with col1:
            lang = st.selectbox("Language", options=["en", "ru", "zh", "ko"])
        with col2:
            model_name = st.selectbox("Model Name", options=list(SUPPORTED_MODELS.keys()) + ["Custom"])
        with col3:
            model_path = st.text_input("Model Path", value="")

        components.update({"lang": lang, "model_name": model_name, "model_path": model_path})

    # Second container: Row 2 - Finetuning Type, Checkpoint Path
    with st.container(border=True):  # Second container
        col1, col2 = st.columns([1, 6])
        with col1:
            finetuning_type = st.selectbox("Finetuning Type", options=METHODS, index=0)
        with col2:
            checkpoint_path = st.selectbox("Checkpoint Path", options=["checkpoint.pth", "test.pth"])

        components.update({"finetuning_type": finetuning_type, "checkpoint_path": checkpoint_path})

    # Third container: Row 3 - Quantization Bit, Method, Template, Rope Scaling, Booster
    with st.container(border=True):  # Third container
        col1, col2, col3, col4, col5 = st.columns([2, 2, 2, 3, 5])
        with col1:
            quantization_bit = st.selectbox("Quantization Bit", options=["none", "8", "4"], index=0)
        with col2:
            quantization_method = st.selectbox("Quantization Method", options=["bitsandbytes", "hqq", "eetq"], index=0)
        with col3:
            template = st.selectbox("Template", options=list(TEMPLATES.keys()), index=0)
        with col4:
            rope_scaling = st.radio("Rope Scaling", options=["none", "linear", "dynamic"], index=0)
        with col5:
            booster = st.radio(
                "Booster",
                options=["auto", "flashattn2", "unsloth", "liger_kernel"],
                index=0,
            )

        components.update(
            {
                "quantization_bit": quantization_bit,
                "quantization_method": quantization_method,
                "template": template,
                "rope_scaling": rope_scaling,
                "booster": booster,
            }
        )

    # Callbacks for dynamic updates
    if model_name:
        model_info = get_model_info(model_name)
        st.write(f"Model Info: {model_info}")
        model_path = model_info.get("path", "")
        template = model_info.get("template", "default")
        st.write(f"Suggested Model Path: {model_path}, Template: {template}")

    if finetuning_type:
        available_quantization = can_quantize(finetuning_type)
        quantization_bit = st.selectbox("Updated Quantization Bit", options=available_quantization)

    if checkpoint_path:
        available_checkpoints = list_checkpoints(model_name, finetuning_type)
        checkpoint_path = st.multiselect("Available Checkpoints", options=available_checkpoints)

    return components
