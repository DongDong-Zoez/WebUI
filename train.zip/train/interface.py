import os
import streamlit as st
from components import (
    create_chat_box,
    create_eval_tab,
    create_export_tab,
    create_infer_tab,
    create_top,
    create_train_tab,
)
from css import CSS
from engine import Engine


def create_ui(demo_mode: bool = False) -> None:
    engine = Engine(demo_mode=demo_mode, pure_chat=False)

    st.set_page_config(page_title="LLaMA Board", page_icon=":guardsman:", layout="wide")
    st.markdown(f"<style>{CSS}</style>", unsafe_allow_html=True)

    if demo_mode:
        st.title("LLaMA Board: A One-stop Web UI for Getting Started with LLaMA Factory")
        st.markdown(
            '<h3><center>Visit <a href="https://github.com/hiyouga/LLaMA-Factory" target="_blank">'
            "LLaMA Factory</a> for details.</center></h3>", unsafe_allow_html=True
        )
        st.button("Duplicate Space for private use")

    # Top section
    engine.manager.add_elems("top", create_top())
    # lang = st.selectbox("Language", options=["en", "ru", "zh", "ko"])

    tabs = st.tabs(["Train", "Evaluate & Predict", "Chat", "Export"])
    with tabs[0]:
        engine.manager.add_elems("train", create_train_tab(engine))

    with tabs[1]:
        engine.manager.add_elems("eval", create_eval_tab(engine))

    with tabs[2]:
        engine.manager.add_elems("infer", create_infer_tab(engine))

    if not demo_mode:
        with tabs[3]:
            engine.manager.add_elems("export", create_export_tab(engine))

    # Language change functionality
    # if lang:
    #     engine.change_lang(lang)
    #     save_config(lang)

    engine.resume()

def create_web_demo() -> None:
    engine = Engine(pure_chat=True)

    st.set_page_config(page_title="Web Demo", page_icon=":guardsman:", layout="wide")
    st.markdown(f"<style>{CSS}</style>", unsafe_allow_html=True)

    lang = st.selectbox("Language", ["en", "ru", "zh", "ko"], index=0)

    engine.manager.add_elems("top", dict(lang=lang))

    _, _, chat_elems = create_chat_box(engine, visible=True)
    engine.manager.add_elems("infer", chat_elems)

    # Language change functionality
    if lang:
        engine.change_lang(lang)
        save_config(lang)

    engine.resume()

def run_web_ui() -> None:
    gradio_ipv6 = os.getenv("GRADIO_IPV6", "0").lower() in ["true", "1"]
    gradio_share = os.getenv("GRADIO_SHARE", "0").lower() in ["true", "1"]
    server_name = os.getenv("GRADIO_SERVER_NAME", "[::]" if gradio_ipv6 else "0.0.0.0")

    create_ui()

def run_web_demo() -> None:
    gradio_ipv6 = os.getenv("GRADIO_IPV6", "0").lower() in ["true", "1"]
    gradio_share = os.getenv("GRADIO_SHARE", "0").lower() in ["true", "1"]
    server_name = os.getenv("GRADIO_SERVER_NAME", "[::]" if gradio_ipv6 else "0.0.0.0")

    create_web_demo()

